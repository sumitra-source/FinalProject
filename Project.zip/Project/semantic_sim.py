# Script using the SpaCy library to measure the semantic similarity between two files

import spacy

# Load the English language model
nlp = spacy.load("en_core_web_md")

def file_to_text(filepath):
    with open(filepath, "r", encoding="utf-8") as file:
        text = file.read()
    return text

def calculate_similarity(text1, text2):
    doc1 = nlp(text1)
    doc2 = nlp(text2)
    similarity = doc1.similarity(doc2)
    return similarity

def main():
    # File paths
    file1_path = "sumi_gpt.txt"
    file2_path = "sumi_rwkv.txt"

    # Read text from files
    text1 = file_to_text(file1_path)
    text2 = file_to_text(file2_path)

    # Calculate semantic similarity
    similarity_score = calculate_similarity(text1, text2)
    print("Semantic similarity between the two files:", similarity_score)

if __name__ == "__main__":
    main()
