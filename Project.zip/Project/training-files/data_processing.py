# Dataset preprocessing for RWKV finetuning
# Convert plaintext to .jsonl format: https://github.com/josStorer/RWKV-Runner/blob/master/finetune/data/sample.jsonl
import json

# Function to convert text to JSONL format
def text_to_jsonl(text):
    conversations = text.strip().split('\n\n')
    jsonl_data = []

    for conversation in conversations:
        dialogue_lines = conversation.split('\n')
        dialogue_text = '\n'.join(dialogue_lines)
        jsonl_data.append({"text": dialogue_text})

    return jsonl_data

# Function to read text from a file
def read_text_from_file(file_path):
    with open(file_path, 'r') as f:
        return f.read()

# Function to write JSONL data to a file
def write_jsonl_to_file(jsonl_data, file_path):
    with open(file_path, 'w') as f:
        for item in jsonl_data:
            f.write(json.dumps(item) + '\n')

# Input and output file paths
input_file = 'input.txt'
output_file = 'input_formatted.txt'

# Read text from input file
input_text = read_text_from_file(input_file)

# Convert text to JSONL format
jsonl_data = text_to_jsonl(input_text)

# Write JSONL data to output file
write_jsonl_to_file(jsonl_data, output_file)

print("Conversion completed. Output written to", output_file)
